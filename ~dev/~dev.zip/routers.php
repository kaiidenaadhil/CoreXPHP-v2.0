<?php
// paper of routes
$app->router->get('/paper', [PaperController::class, 'paperIndex']);
$app->router->get('/paper/build', [PaperController::class, 'paperBuild']);
$app->router->post('/paper/build', [PaperController::class, 'paperRecord']);
$app->router->get('/paper/{paperIdentify}/destroy', [PaperController::class, 'paperDestroy']);
$app->router->get('/paper/{paperIdentify}/modify', [PaperController::class, 'paperModify']);
$app->router->post('/paper/{paperIdentify}/modify', [PaperController::class, 'paperEdit']);
$app->router->get('/paper/{paperIdentify}', [PaperController::class, 'paperDisplay']);

// lamination of routes
$app->router->get('/lamination', [LaminationController::class, 'laminationIndex']);
$app->router->get('/lamination/build', [LaminationController::class, 'laminationBuild']);
$app->router->post('/lamination/build', [LaminationController::class, 'laminationRecord']);
$app->router->get('/lamination/{laminationIdentify}/destroy', [LaminationController::class, 'laminationDestroy']);
$app->router->get('/lamination/{laminationIdentify}/modify', [LaminationController::class, 'laminationModify']);
$app->router->post('/lamination/{laminationIdentify}/modify', [LaminationController::class, 'laminationEdit']);
$app->router->get('/lamination/{laminationIdentify}', [LaminationController::class, 'laminationDisplay']);

// paper of routes
$app->router->get('/paper', [PaperController::class, 'paperIndex']);
$app->router->get('/paper/build', [PaperController::class, 'paperBuild']);
$app->router->post('/paper/build', [PaperController::class, 'paperRecord']);
$app->router->get('/paper/{paperIdentify}/destroy', [PaperController::class, 'paperDestroy']);
$app->router->get('/paper/{paperIdentify}/modify', [PaperController::class, 'paperModify']);
$app->router->post('/paper/{paperIdentify}/modify', [PaperController::class, 'paperEdit']);
$app->router->get('/paper/{paperIdentify}', [PaperController::class, 'paperDisplay']);

// paper of routes
$app->router->get('/paper', [PaperController::class, 'paperIndex']);
$app->router->get('/paper/build', [PaperController::class, 'paperBuild']);
$app->router->post('/paper/build', [PaperController::class, 'paperRecord']);
$app->router->get('/paper/{paperIdentify}/destroy', [PaperController::class, 'paperDestroy']);
$app->router->get('/paper/{paperIdentify}/modify', [PaperController::class, 'paperModify']);
$app->router->post('/paper/{paperIdentify}/modify', [PaperController::class, 'paperEdit']);
$app->router->get('/paper/{paperIdentify}', [PaperController::class, 'paperDisplay']);

// paper of routes
$app->router->get('/paper', [PaperController::class, 'paperIndex']);
$app->router->get('/paper/build', [PaperController::class, 'paperBuild']);
$app->router->post('/paper/build', [PaperController::class, 'paperRecord']);
$app->router->get('/paper/{paperIdentify}/destroy', [PaperController::class, 'paperDestroy']);
$app->router->get('/paper/{paperIdentify}/modify', [PaperController::class, 'paperModify']);
$app->router->post('/paper/{paperIdentify}/modify', [PaperController::class, 'paperEdit']);
$app->router->get('/paper/{paperIdentify}', [PaperController::class, 'paperDisplay']);

// factory of routes
$app->router->get('/factory', [FactoryController::class, 'factoryIndex']);
$app->router->get('/factory/build', [FactoryController::class, 'factoryBuild']);
$app->router->post('/factory/build', [FactoryController::class, 'factoryRecord']);
$app->router->get('/factory/{factoryIdentify}/destroy', [FactoryController::class, 'factoryDestroy']);
$app->router->get('/factory/{factoryIdentify}/modify', [FactoryController::class, 'factoryModify']);
$app->router->post('/factory/{factoryIdentify}/modify', [FactoryController::class, 'factoryEdit']);
$app->router->get('/factory/{factoryIdentify}', [FactoryController::class, 'factoryDisplay']);

// templete of routes
$app->router->get('/templete', [TempleteController::class, 'templeteIndex']);
$app->router->get('/templete/build', [TempleteController::class, 'templeteBuild']);
$app->router->post('/templete/build', [TempleteController::class, 'templeteRecord']);
$app->router->get('/templete/{templeteIdentify}/destroy', [TempleteController::class, 'templeteDestroy']);
$app->router->get('/templete/{templeteIdentify}/modify', [TempleteController::class, 'templeteModify']);
$app->router->post('/templete/{templeteIdentify}/modify', [TempleteController::class, 'templeteEdit']);
$app->router->get('/templete/{templeteIdentify}', [TempleteController::class, 'templeteDisplay']);

// templete of routes
$app->router->get('/templete', [TempleteController::class, 'templeteIndex']);
$app->router->get('/templete/build', [TempleteController::class, 'templeteBuild']);
$app->router->post('/templete/build', [TempleteController::class, 'templeteRecord']);
$app->router->get('/templete/{templeteIdentify}/destroy', [TempleteController::class, 'templeteDestroy']);
$app->router->get('/templete/{templeteIdentify}/modify', [TempleteController::class, 'templeteModify']);
$app->router->post('/templete/{templeteIdentify}/modify', [TempleteController::class, 'templeteEdit']);
$app->router->get('/templete/{templeteIdentify}', [TempleteController::class, 'templeteDisplay']);

// templete of routes
$app->router->get('/templete', [TempleteController::class, 'templeteIndex']);
$app->router->get('/templete/build', [TempleteController::class, 'templeteBuild']);
$app->router->post('/templete/build', [TempleteController::class, 'templeteRecord']);
$app->router->get('/templete/{templeteIdentify}/destroy', [TempleteController::class, 'templeteDestroy']);
$app->router->get('/templete/{templeteIdentify}/modify', [TempleteController::class, 'templeteModify']);
$app->router->post('/templete/{templeteIdentify}/modify', [TempleteController::class, 'templeteEdit']);
$app->router->get('/templete/{templeteIdentify}', [TempleteController::class, 'templeteDisplay']);

// templete of routes
$app->router->get('/templete', [TempleteController::class, 'templeteIndex']);
$app->router->get('/templete/build', [TempleteController::class, 'templeteBuild']);
$app->router->post('/templete/build', [TempleteController::class, 'templeteRecord']);
$app->router->get('/templete/{templeteIdentify}/destroy', [TempleteController::class, 'templeteDestroy']);
$app->router->get('/templete/{templeteIdentify}/modify', [TempleteController::class, 'templeteModify']);
$app->router->post('/templete/{templeteIdentify}/modify', [TempleteController::class, 'templeteEdit']);
$app->router->get('/templete/{templeteIdentify}', [TempleteController::class, 'templeteDisplay']);

// templete of routes
$app->router->get('/templete', [TempleteController::class, 'templeteIndex']);
$app->router->get('/templete/build', [TempleteController::class, 'templeteBuild']);
$app->router->post('/templete/build', [TempleteController::class, 'templeteRecord']);
$app->router->get('/templete/{templeteIdentify}/destroy', [TempleteController::class, 'templeteDestroy']);
$app->router->get('/templete/{templeteIdentify}/modify', [TempleteController::class, 'templeteModify']);
$app->router->post('/templete/{templeteIdentify}/modify', [TempleteController::class, 'templeteEdit']);
$app->router->get('/templete/{templeteIdentify}', [TempleteController::class, 'templeteDisplay']);

// Paper of routes
$app->router->get('/Paper', [PaperController::class, 'PaperIndex']);
$app->router->get('/Paper/build', [PaperController::class, 'PaperBuild']);
$app->router->post('/Paper/build', [PaperController::class, 'PaperRecord']);
$app->router->get('/Paper/{PaperIdentify}/destroy', [PaperController::class, 'PaperDestroy']);
$app->router->get('/Paper/{PaperIdentify}/modify', [PaperController::class, 'PaperModify']);
$app->router->post('/Paper/{PaperIdentify}/modify', [PaperController::class, 'PaperEdit']);
$app->router->get('/Paper/{PaperIdentify}', [PaperController::class, 'PaperDisplay']);

// paper of routes
$app->router->get('/paper', [PaperController::class, 'paperIndex']);
$app->router->get('/paper/build', [PaperController::class, 'paperBuild']);
$app->router->post('/paper/build', [PaperController::class, 'paperRecord']);
$app->router->get('/paper/{paperIdentify}/destroy', [PaperController::class, 'paperDestroy']);
$app->router->get('/paper/{paperIdentify}/modify', [PaperController::class, 'paperModify']);
$app->router->post('/paper/{paperIdentify}/modify', [PaperController::class, 'paperEdit']);
$app->router->get('/paper/{paperIdentify}', [PaperController::class, 'paperDisplay']);

// paper of routes
$app->router->get('/paper', [PaperController::class, 'paperIndex']);
$app->router->get('/paper/build', [PaperController::class, 'paperBuild']);
$app->router->post('/paper/build', [PaperController::class, 'paperRecord']);
$app->router->get('/paper/{paperIdentify}/destroy', [PaperController::class, 'paperDestroy']);
$app->router->get('/paper/{paperIdentify}/modify', [PaperController::class, 'paperModify']);
$app->router->post('/paper/{paperIdentify}/modify', [PaperController::class, 'paperEdit']);
$app->router->get('/paper/{paperIdentify}', [PaperController::class, 'paperDisplay']);

// heroVideos of routes
$app->router->get('/heroVideos', [HeroVideosController::class, 'heroVideosIndex']);
$app->router->get('/heroVideos/build', [HeroVideosController::class, 'heroVideosBuild']);
$app->router->post('/heroVideos/build', [HeroVideosController::class, 'heroVideosRecord']);
$app->router->get('/heroVideos/{heroVideosIdentify}/destroy', [HeroVideosController::class, 'heroVideosDestroy']);
$app->router->get('/heroVideos/{heroVideosIdentify}/modify', [HeroVideosController::class, 'heroVideosModify']);
$app->router->post('/heroVideos/{heroVideosIdentify}/modify', [HeroVideosController::class, 'heroVideosEdit']);
$app->router->get('/heroVideos/{heroVideosIdentify}', [HeroVideosController::class, 'heroVideosDisplay']);

// heroVideos of routes
$app->router->get('/heroVideos', [HeroVideosController::class, 'heroVideosIndex']);
$app->router->get('/heroVideos/build', [HeroVideosController::class, 'heroVideosBuild']);
$app->router->post('/heroVideos/build', [HeroVideosController::class, 'heroVideosRecord']);
$app->router->get('/heroVideos/{heroVideosIdentify}/destroy', [HeroVideosController::class, 'heroVideosDestroy']);
$app->router->get('/heroVideos/{heroVideosIdentify}/modify', [HeroVideosController::class, 'heroVideosModify']);
$app->router->post('/heroVideos/{heroVideosIdentify}/modify', [HeroVideosController::class, 'heroVideosEdit']);
$app->router->get('/heroVideos/{heroVideosIdentify}', [HeroVideosController::class, 'heroVideosDisplay']);

// heroVideos of routes
$app->router->get('/heroVideos', [HeroVideosController::class, 'heroVideosIndex']);
$app->router->get('/heroVideos/build', [HeroVideosController::class, 'heroVideosBuild']);
$app->router->post('/heroVideos/build', [HeroVideosController::class, 'heroVideosRecord']);
$app->router->get('/heroVideos/{heroVideosIdentify}/destroy', [HeroVideosController::class, 'heroVideosDestroy']);
$app->router->get('/heroVideos/{heroVideosIdentify}/modify', [HeroVideosController::class, 'heroVideosModify']);
$app->router->post('/heroVideos/{heroVideosIdentify}/modify', [HeroVideosController::class, 'heroVideosEdit']);
$app->router->get('/heroVideos/{heroVideosIdentify}', [HeroVideosController::class, 'heroVideosDisplay']);

// heroVideos of routes
$app->router->get('/heroVideos', [HeroVideosController::class, 'heroVideosIndex']);
$app->router->get('/heroVideos/build', [HeroVideosController::class, 'heroVideosBuild']);
$app->router->post('/heroVideos/build', [HeroVideosController::class, 'heroVideosRecord']);
$app->router->get('/heroVideos/{heroVideosIdentify}/destroy', [HeroVideosController::class, 'heroVideosDestroy']);
$app->router->get('/heroVideos/{heroVideosIdentify}/modify', [HeroVideosController::class, 'heroVideosModify']);
$app->router->post('/heroVideos/{heroVideosIdentify}/modify', [HeroVideosController::class, 'heroVideosEdit']);
$app->router->get('/heroVideos/{heroVideosIdentify}', [HeroVideosController::class, 'heroVideosDisplay']);

// heroVideos of routes
$app->router->get('/heroVideos', [HeroVideosController::class, 'heroVideosIndex']);
$app->router->get('/heroVideos/build', [HeroVideosController::class, 'heroVideosBuild']);
$app->router->post('/heroVideos/build', [HeroVideosController::class, 'heroVideosRecord']);
$app->router->get('/heroVideos/{heroVideosIdentify}/destroy', [HeroVideosController::class, 'heroVideosDestroy']);
$app->router->get('/heroVideos/{heroVideosIdentify}/modify', [HeroVideosController::class, 'heroVideosModify']);
$app->router->post('/heroVideos/{heroVideosIdentify}/modify', [HeroVideosController::class, 'heroVideosEdit']);
$app->router->get('/heroVideos/{heroVideosIdentify}', [HeroVideosController::class, 'heroVideosDisplay']);

// heroVideos of routes
$app->router->get('/heroVideos', [HeroVideosController::class, 'heroVideosIndex']);
$app->router->get('/heroVideos/build', [HeroVideosController::class, 'heroVideosBuild']);
$app->router->post('/heroVideos/build', [HeroVideosController::class, 'heroVideosRecord']);
$app->router->get('/heroVideos/{heroVideosIdentify}/destroy', [HeroVideosController::class, 'heroVideosDestroy']);
$app->router->get('/heroVideos/{heroVideosIdentify}/modify', [HeroVideosController::class, 'heroVideosModify']);
$app->router->post('/heroVideos/{heroVideosIdentify}/modify', [HeroVideosController::class, 'heroVideosEdit']);
$app->router->get('/heroVideos/{heroVideosIdentify}', [HeroVideosController::class, 'heroVideosDisplay']);

// orders of routes
$app->router->get('/orders', [OrdersController::class, 'ordersIndex']);
$app->router->get('/orders/build', [OrdersController::class, 'ordersBuild']);
$app->router->post('/orders/build', [OrdersController::class, 'ordersRecord']);
$app->router->get('/orders/{ordersIdentify}/destroy', [OrdersController::class, 'ordersDestroy']);
$app->router->get('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersModify']);
$app->router->post('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersEdit']);
$app->router->get('/orders/{ordersIdentify}', [OrdersController::class, 'ordersDisplay']);

// orders of routes
$app->router->get('/orders', [OrdersController::class, 'ordersIndex']);
$app->router->get('/orders/build', [OrdersController::class, 'ordersBuild']);
$app->router->post('/orders/build', [OrdersController::class, 'ordersRecord']);
$app->router->get('/orders/{ordersIdentify}/destroy', [OrdersController::class, 'ordersDestroy']);
$app->router->get('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersModify']);
$app->router->post('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersEdit']);
$app->router->get('/orders/{ordersIdentify}', [OrdersController::class, 'ordersDisplay']);

// orders of routes
$app->router->get('/orders', [OrdersController::class, 'ordersIndex']);
$app->router->get('/orders/build', [OrdersController::class, 'ordersBuild']);
$app->router->post('/orders/build', [OrdersController::class, 'ordersRecord']);
$app->router->get('/orders/{ordersIdentify}/destroy', [OrdersController::class, 'ordersDestroy']);
$app->router->get('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersModify']);
$app->router->post('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersEdit']);
$app->router->get('/orders/{ordersIdentify}', [OrdersController::class, 'ordersDisplay']);

// orders of routes
$app->router->get('/orders', [OrdersController::class, 'ordersIndex']);
$app->router->get('/orders/build', [OrdersController::class, 'ordersBuild']);
$app->router->post('/orders/build', [OrdersController::class, 'ordersRecord']);
$app->router->get('/orders/{ordersIdentify}/destroy', [OrdersController::class, 'ordersDestroy']);
$app->router->get('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersModify']);
$app->router->post('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersEdit']);
$app->router->get('/orders/{ordersIdentify}', [OrdersController::class, 'ordersDisplay']);

// orders of routes
$app->router->get('/orders', [OrdersController::class, 'ordersIndex']);
$app->router->get('/orders/build', [OrdersController::class, 'ordersBuild']);
$app->router->post('/orders/build', [OrdersController::class, 'ordersRecord']);
$app->router->get('/orders/{ordersIdentify}/destroy', [OrdersController::class, 'ordersDestroy']);
$app->router->get('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersModify']);
$app->router->post('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersEdit']);
$app->router->get('/orders/{ordersIdentify}', [OrdersController::class, 'ordersDisplay']);

// orders of routes
$app->router->get('/orders', [OrdersController::class, 'ordersIndex']);
$app->router->get('/orders/build', [OrdersController::class, 'ordersBuild']);
$app->router->post('/orders/build', [OrdersController::class, 'ordersRecord']);
$app->router->get('/orders/{ordersIdentify}/destroy', [OrdersController::class, 'ordersDestroy']);
$app->router->get('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersModify']);
$app->router->post('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersEdit']);
$app->router->get('/orders/{ordersIdentify}', [OrdersController::class, 'ordersDisplay']);

// orders of routes
$app->router->get('/orders', [OrdersController::class, 'ordersIndex']);
$app->router->get('/orders/build', [OrdersController::class, 'ordersBuild']);
$app->router->post('/orders/build', [OrdersController::class, 'ordersRecord']);
$app->router->get('/orders/{ordersIdentify}/destroy', [OrdersController::class, 'ordersDestroy']);
$app->router->get('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersModify']);
$app->router->post('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersEdit']);
$app->router->get('/orders/{ordersIdentify}', [OrdersController::class, 'ordersDisplay']);

// code of routes
$app->router->get('/code', [CodeController::class, 'codeIndex']);
$app->router->get('/code/build', [CodeController::class, 'codeBuild']);
$app->router->post('/code/build', [CodeController::class, 'codeRecord']);
$app->router->get('/code/{codeIdentify}/destroy', [CodeController::class, 'codeDestroy']);
$app->router->get('/code/{codeIdentify}/modify', [CodeController::class, 'codeModify']);
$app->router->post('/code/{codeIdentify}/modify', [CodeController::class, 'codeEdit']);
$app->router->get('/code/{codeIdentify}', [CodeController::class, 'codeDisplay']);

// orders of routes
$app->router->get('/orders', [OrdersController::class, 'ordersIndex']);
$app->router->get('/orders/build', [OrdersController::class, 'ordersBuild']);
$app->router->post('/orders/build', [OrdersController::class, 'ordersRecord']);
$app->router->get('/orders/{ordersIdentify}/destroy', [OrdersController::class, 'ordersDestroy']);
$app->router->get('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersModify']);
$app->router->post('/orders/{ordersIdentify}/modify', [OrdersController::class, 'ordersEdit']);
$app->router->get('/orders/{ordersIdentify}', [OrdersController::class, 'ordersDisplay']);

// product of routes
$app->router->get('/product', [ProductController::class, 'productIndex']);
$app->router->get('/product/build', [ProductController::class, 'productBuild']);
$app->router->post('/product/build', [ProductController::class, 'productRecord']);
$app->router->get('/product/{productIdentify}/destroy', [ProductController::class, 'productDestroy']);
$app->router->get('/product/{productIdentify}/modify', [ProductController::class, 'productModify']);
$app->router->post('/product/{productIdentify}/modify', [ProductController::class, 'productEdit']);
$app->router->get('/product/{productIdentify}', [ProductController::class, 'productDisplay']);

// product of routes
$app->router->get('/product', [ProductController::class, 'productIndex']);
$app->router->get('/product/build', [ProductController::class, 'productBuild']);
$app->router->post('/product/build', [ProductController::class, 'productRecord']);
$app->router->get('/product/{productIdentify}/destroy', [ProductController::class, 'productDestroy']);
$app->router->get('/product/{productIdentify}/modify', [ProductController::class, 'productModify']);
$app->router->post('/product/{productIdentify}/modify', [ProductController::class, 'productEdit']);
$app->router->get('/product/{productIdentify}', [ProductController::class, 'productDisplay']);
